# Temperature Converter
def to_celsius(f):
    return (f - 32) * 5/9

def to_fahrenheit(c):
    return (c * 9/5) + 32

choice = input("Convert to (C)elsius or (F)ahrenheit? ").strip().upper()
temp = float(input("Enter the temperature: "))

if choice == 'C':
    print("Temperature in Celsius:", to_celsius(temp))
elif choice == 'F':
    print("Temperature in Fahrenheit:", to_fahrenheit(temp))
else:
    print("Invalid choice")
