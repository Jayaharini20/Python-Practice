# Basic Task Manager (CRUD)
tasks = []

def show_tasks():
    if not tasks:
        print("No tasks.")
    for i, task in enumerate(tasks):
        print(f"{i+1}. {task}")

while True:
    print("\n1. Add 2. View 3. Update 4. Delete 5. Exit")
    choice = input("Choose: ")

    if choice == '1':
        task = input("Enter task: ")
        tasks.append(task)
    elif choice == '2':
        show_tasks()
    elif choice == '3':
        show_tasks()
        i = int(input("Enter task number to update: ")) - 1
        if 0 <= i < len(tasks):
            tasks[i] = input("Enter new task: ")
    elif choice == '4':
        show_tasks()
        i = int(input("Enter task number to delete: ")) - 1
        if 0 <= i < len(tasks):
            tasks.pop(i)
    elif choice == '5':
        break
    else:
        print("Invalid option")
